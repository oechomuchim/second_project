package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class MemberDAO {
	DBConnectionMgr mgr;
	
	public MemberDAO(){
		mgr = DBConnectionMgr.getInstance();	//싱글톤으로 없으면 만들어주고 있으면 있는걸 당겨옴~
		
	}
	
	public void Insert(MemberDTO dto) throws Exception{
		//1, 2단계를 해주는 DBConnectionMgr객체 필요
		Connection con = mgr.getConnection();	//mgr객체는 connection이 10개 만들어져 있고 이중 1개를 가져온 것을 의미
		
		//3단계. SQL문 결정
		String sql = "insert into member values(?,?,?,?,?,?,?,?)";
		
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, dto.getId());
		ps.setString(2, dto.getPw());
		ps.setString(3, dto.getRpw());
		ps.setString(4, dto.getTel());
		ps.setString(5, dto.getYear());
		ps.setString(6, dto.getMonth());
		ps.setString(7, dto.getDay());
		ps.setString(8, dto.getAddr());

		//4단계. SQL문 실행 요청
		ps.executeUpdate();
		
	}
}
