package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TravelDAO {
	DBConnectionMgr mgr;

	public TravelDAO() {
	mgr = DBConnectionMgr.getInstance();
	}
	// dao�� �ܰ踦 ���� ȿ�������� ����
	
	// insert
	public void insert(TravelDTO dto) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/projectga";
		String user = "root";
		String password ="1234";
		
		Connection con;
		PreparedStatement ps;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
			String sql = "insert into travel values(?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getRegion());
			ps.setString(3, dto.getPlace());
			ps.setString(4, dto.getTheme());
			ps.setString(5, dto.getMember());
			ps.executeUpdate();
		} catch (Exception e) {
		} // catch
	} // insert
	
	// select - ������ ���� �ҷ��ͼ� �� ���� �������� ����
	public void select(String inputName) throws Exception{
		TravelDTO dto = null;
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/projectga";
		String user = "root";
		String password ="1234";
		
		Connection con;
		PreparedStatement ps;
		ResultSet rs;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
			String sql = "select * from travel";
			ps = con.prepareStatement(sql);
			ps.setString(1, inputName);
			rs = ps.executeQuery();
			
			if (rs.next()) { 
				dto = new TravelDTO();
				
				String name = rs.getString(1);  
				String region = rs.getString(2);  
				String place = rs.getString(3);  
				String theme = rs.getString(4);  
				String member = rs.getString(5);  
				
				dto.setName(name);
				dto.setRegion(region);
				dto.setPlace(place);
				dto.setTheme(theme);
				dto.setMember(member);
				ps.executeUpdate();
				
				mgr.freeConnection(con, ps);
				} // if
			} catch (Exception e) {
			} // catch
		} // select
	
	public ArrayList selectAll() throws Exception{
	      ArrayList list = new ArrayList();
	      Connection con = mgr.getConnection();
	      TravelDTO dto = null; //������ �������� = ������ ��ġ
	      
	         //3. SQL�� ����(��üȭ)
	         String sql = "select * from travel";
	         PreparedStatement ps = con.prepareStatement(sql);
	         System.out.println("SQL�� ��üȭ OK");
	         //4. SQL�� ����
	         ResultSet rs = ps.executeQuery();
	         
	         while(rs.next()) {
	            dto = new TravelDTO();
	            String name = rs.getString(1);
	            String region = rs.getString(2);
	            String place = rs.getString(3);
	            String theme = rs.getString(4);
	            String member = rs.getString(5);
	            String picture = rs.getString(6);
	            
	            dto.setName(name);
	            dto.setRegion(region);
	            dto.setPlace(place);
	            dto.setTheme(theme);
	            dto.setMember(member);
	            dto.setPicture(picture);
	            
	            list.add(dto);
	         }
	         System.out.println("SQL�� ���� OK");
	         
	         try {
	            rs.close();
	            ps.close();
	            con.close();
	         } catch (SQLException e) {
	            //e.printStackTrace();
	            System.out.println("�ڿ� ���� �� ���� �߻�!!");
	         }
	   return list;
	}   
} // class